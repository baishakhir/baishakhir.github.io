int g, h;
int test(int condition) {
  int x;
  if (condition==1){
     x=g;
     x=h;
  }
  return x;
}
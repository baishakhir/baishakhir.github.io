int main(){
	int a;
	if(a=5){
		return 1;
	}

	if(a==6){
		return 2;
	}
	if(a==7){
		if(a=8)return 3;
	}
	return 0;
}

int main(){
	int a = 5;
	if(a==2) return 1;
	else return 0;
}

